import React, { useState } from "react";

const CategoryIcons = {
  "Intelligence Artificielle": (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="currentColor"
      className="w-6 h-6 text-[var(--sec)] opacity-70"
    >
      <path d="M12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2ZM12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4ZM12 5C13.6569 5 15 6.34315 15 8C15 9.65685 13.6569 11 12 11C10.3431 11 9 9.65685 9 8C9 6.34315 10.3431 5 12 5ZM12 7C11.4477 7 11 7.44772 11 8C11 8.55228 11.4477 9 12 9C12.5523 9 13 8.55228 13 8C13 7.44772 12.5523 7 12 7ZM10.1334 11.6964L9.75732 14.8364C9.65819 15.6938 10.282 16.4742 11.1394 16.5733C11.5733 16.6223 12.0112 16.505 12.3679 16.2428L12.5 16.1444L14.4243 18.0686C14.8148 18.4592 15.4479 18.4592 15.8385 18.0686C16.229 17.6781 16.229 17.045 15.8385 16.6544L13.9142 14.7301L13.9338 14.7158C14.3728 14.4035 14.6552 13.8892 14.6968 13.318L14.7009 13.1636L15.0769 10.0235C15.176 9.16614 14.5522 8.38569 13.6949 8.28655C13.0097 8.2035 12.3808 8.55539 12.0914 9.14347L12.0007 9.34336L11.9117 9.14356C11.6309 8.57175 11.0419 8.21798 10.3957 8.28233L10.2042 8.30326C9.34693 8.40239 8.72308 9.18284 8.82222 10.0402L9.19818 13.1802C9.23514 13.5139 9.36528 13.821 9.56832 14.0713L9.67543 14.1887L7.75114 16.113C7.36062 16.5035 7.36062 17.1367 7.75114 17.5272C8.14167 17.9177 8.77483 17.9177 9.16536 17.5272L11.0896 15.6029L11.1109 15.6173C11.5465 15.9265 12.0764 16.0462 12.589 15.9507L12.7557 15.9163L12.3797 12.7763C12.2805 11.919 11.5001 11.2951 10.6428 11.3943C10.456 11.4163 10.2846 11.4613 10.1334 11.6964Z"></path>
    </svg>
  ),
  "Développement & Tech": (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="currentColor"
      className="w-6 h-6 text-[var(--sec)] opacity-70"
    >
      <path d="M24 12L18.3431 17.6569L16.9289 16.2426L21.1716 12L16.9289 7.75736L18.3431 6.34315L24 12ZM2.82843 12L7.07107 16.2426L5.65685 17.6569L0 12L5.65685 6.34315L7.07107 7.75736L2.82843 12ZM9.78845 21H7.66009L14.2116 3H16.3399L9.78845 21Z"></path>
    </svg>
  ),
  "Gestion de Projets & DevOps": (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="currentColor"
      className="w-6 h-6 text-[var(--sec)] opacity-70"
    >
      <path d="M5 3V19H21V21H3V3H5ZM20.2929 6.29289L21.7071 7.70711L16 13.4142L13 10.4142L8.29289 15.1213L6.87868 13.7071L13 7.58579L16 10.5858L20.2929 6.29289Z"></path>
    </svg>
  ),
};

const SkillsList = () => {
  const [openItem, setOpenItem] = useState<string | null>(null);

  const skills = {
    "Intelligence Artificielle": [
      "LLMs (Large Language Models)",
      "Retrieval-Augmented Generation (RAG)",
      "IA générative",
      "Fine-tuning de modèles IA",
      "Langchain"
    ],
    "Développement & Tech": [
      "Python",
      "FastAPI",
      "SQL",
      "Développement web",
      "Bash"
    ],
    "Gestion de Projets & DevOps": [
      "Git",
      "Docker",
      "Gestion de projet IT",
      "Administration réseau",
      "Documentation technique"
    ],
  };

  const toggleItem = (item: string) => {
    setOpenItem(openItem === item ? null : item);
  };

  return (
    <div className="text-left pt-3 md:pt-9">
      <h3 className="text-[var(--white)] text-3xl md:text-4xl font-semibold md:mb-6">
        Mes compétences
      </h3>
      <ul className="space-y-4 mt-4 text-lg">
        {Object.entries(skills).map(([category, items]) => (
          <li key={category} className="w-full">
            <div
              onClick={() => toggleItem(category)}
              className="md:w-[400px] w-full bg-[#1414149c] rounded-2xl text-left hover:bg-opacity-80 transition-all border border-[var(--white-icon-tr)] cursor-pointer overflow-hidden"
            >
              <div className="flex items-center gap-3 p-4">
                {CategoryIcons[category]}
                <div className="flex items-center gap-2 flex-grow justify-between">
                  <div className="min-w-0 max-w-[200px] md:max-w-none overflow-hidden">
                    <span className="block truncate text-[var(--white)] text-lg">
                      {category}
                    </span>
                  </div>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    className={`w-6 h-6 text-[var(--white)] transform transition-transform flex-shrink-0 ${
                      openItem === category ? "rotate-180" : ""
                    }`}
                  >
                    <path d="M11.9999 13.1714L16.9497 8.22168L18.3639 9.63589L11.9999 15.9999L5.63599 9.63589L7.0502 8.22168L11.9999 13.1714Z"></path>
                  </svg>
                </div>
              </div>

              <div
                className={`transition-all duration-300 px-4 ${
                  openItem === category
                    ? "max-h-[500px] pb-4 opacity-100"
                    : "max-h-0 opacity-0"
                }`}
              >
                <ul className="space-y-2 text-[var(--white-icon)] text-sm">
                  {items.map((item, index) => (
                    <div key={index} className="flex items-center">
                      <span className="pl-1">•</span>
                      <li className="pl-3">{item}</li>
                    </div>
                  ))}
                </ul>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default SkillsList;
